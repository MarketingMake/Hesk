<?php if (!defined('IN_SCRIPT')) {die();} $hesk_settings['statuses']=array (
  0 => 
  array (
    'name' => 'Novo',
    'class' => 'open',
  ),
  1 => 
  array (
    'name' => 'Aguardando resposta',
    'class' => 'waitingreply',
  ),
  2 => 
  array (
    'name' => 'Respondido',
    'class' => 'replied',
  ),
  3 => 
  array (
    'name' => 'Resolvido',
    'class' => 'resolved',
  ),
  4 => 
  array (
    'name' => 'Em progresso',
    'class' => 'inprogress',
  ),
  5 => 
  array (
    'name' => 'Em espera',
    'class' => 'onhold',
  ),
);